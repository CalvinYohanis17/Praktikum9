function startQuiz() {
    let score = 0;
    let totalQuestions = 0;
    const operators = ["+", "-", "*"];
  
    while (true) {
      let num1 = Math.floor(Math.random() * 20) + 1;
      let num2 = Math.floor(Math.random() * 20) + 1;
      let operator = operators[Math.floor(Math.random() * operators.length)];
      let question = `What is ${num1} ${operator} ${num2}?`;
      let correctAnswer;
  
      switch (operator) {
        case "+": correctAnswer = num1 + num2; break;
        case "-": correctAnswer = num1 - num2; break;
        case "*": correctAnswer = num1 * num2; break;
      }
  
      let userAnswer = prompt(question);
      if (userAnswer === null || userAnswer.toLowerCase() === "exit") {
        break;
      }
  
      totalQuestions++;
      let parsedAnswer = parseFloat(userAnswer);
      if (Math.abs(parsedAnswer - correctAnswer) < 0.0001) {
        alert("Correct!");
        score++;
      } else {
        alert(`Wrong! The correct answer is ${correctAnswer}`);
      }
    }
  
    if (confirm("Show your result?")) {
      document.getElementById("result").textContent = `Final Score: ${score}/${totalQuestions}`;
      document.getElementById("datetime").textContent = `Finished at: ${new Date().toLocaleString()}`;
    }
  }
  