function jalankan() {
    const hexChars = '1234567890ABCDEF';
    let color = '#';

    for (let i = 0; i < 6; i++) {
        const randomIndex = Math.floor(Math.random() * hexChars.length);
        color += hexChars[randomIndex];
    }

    document.body.style.backgroundColor = color;
    document.getElementById("colorCode").innerText = color;
}
