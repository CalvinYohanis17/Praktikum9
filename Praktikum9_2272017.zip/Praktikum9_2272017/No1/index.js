
let border = prompt("Border persegi (misal 1):");
let tinggi = prompt("Tinggi persegi (px):");
let lebar = prompt("Lebar persegi (px):");
let warna = prompt("Warna persegi (misal: red, blue, #00ff00):");
let isi = prompt("Isi persegi (misal: Hello World):");
let square = document.getElementById("square");
let info = document.getElementById("info");

square.style.width = lebar + "px";
square.style.height = tinggi + "px";
square.style.backgroundColor = warna;
square.style.border = border + "px solid black";
square.innerText = isi;

info.innerHTML = "&copy; 2272017 - Calvin Yohanis";
